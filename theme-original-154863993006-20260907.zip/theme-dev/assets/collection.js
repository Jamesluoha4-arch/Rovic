if (!customElements.get('facet-form')) {
  customElements.define(
    'facet-form',
    class FacetForm extends BaseElementMixin(HTMLFormElement) {
      constructor() {
        super();

        this.dirty = false;
        this.cachedMap = new Map();
        this.isMobile = theme.config.mqlSmall || theme.config.isTouch;
        this.motionReduced = theme.config.motionReduced || this.hasAttribute('motion-reduced');
      }

      connectedCallback() {
        super.connectedCallback();

        this.on(this, 'change', this.onFormChange);
        this.on(this, 'submit', this.onFormSubmit);
      }

      disconnectedCallback() {
        super.disconnectedCallback();

        this.renderAbortController?.abort();
      }

      getAnimationParams() {
        return {
          distance: this.isMobile ? 30 : 50,
          duration: this.motionReduced ? 0.001 : (this.isMobile ? 0.3 : 0.5),
          staggerDelay: this.motionReduced ? 0 : (this.isMobile ? 0.05 : 0.1)
        };
      }

      getVisibleItems(items) {
        const viewportHeight = window.innerHeight + window.scrollY;
        const visible = [];
        const invisible = [];
        
        items.forEach(item => {
          const rect = item.getBoundingClientRect();
          const isVisible = rect.top < viewportHeight && rect.bottom > 0;
          
          if (isVisible) {
            visible.push(item);
          } else {
            invisible.push(item);
          }
        });
        
        return { visible, invisible };
      }

      onFormChange() {
        this.dirty = true;
        this.dispatchEvent(new Event('submit', { cancelable: true }));
      }

      onFormSubmit(event) {
        event.preventDefault();
        if (!this.dirty) return;

        const url = this.buildUrl().toString();
        this.renderSection(url, event);
      }

      buildUrl() {
        const searchParams = new URLSearchParams(new FormData(this));
        const url = new URL(this.action);

        url.search = '';
        searchParams.forEach((value, key) => url.searchParams.append(key, value));

        ['page', 'filter.v.price.gte', 'filter.v.price.lte'].forEach((item) => {
          if (url.searchParams.get(item) === '') {
            url.searchParams.delete(item);
          }
        });

        url.searchParams.set('section_id', theme.utils.sectionId(this));
        return url;
      }

      updateURLHash(url) {
        const clonedUrl = new URL(url);
        clonedUrl.searchParams.delete('section_id');
        history.replaceState({}, '', clonedUrl.toString());
      }

      beforeRenderSection() {
        const container = document.getElementById('ProductGridContainer');
        const items = container.querySelectorAll('.product-card');

        const { distance, duration, staggerDelay } = this.getAnimationParams();
        const { visible: visibleItems, invisible: inVisibleItems } = this.getVisibleItems(items);

        Motion.timeline([
          [visibleItems, { y: distance, opacity: 0, visibility: 'hidden' }, { duration: duration, delay: Motion.stagger(staggerDelay) }],
          [inVisibleItems, { y: distance, opacity: 0, visibility: 'hidden' }, { duration: duration }],
          [container, { y: distance, opacity: 0 }, { duration: duration, easing: 'linear' }]
        ]);
        items.forEach(item => item.style.removeProperty('transform'));

        let headerHeight = 0;
        if (!theme.config.mqlSmall && document.querySelector('header.header')) {
          headerHeight = Math.round(document.querySelector('header.header').clientHeight);
        }
        setTimeout(() => {
          const target = document.querySelector('.collection');
          window.scrollTo({
            top: target.getBoundingClientRect().top + window.scrollY - (theme.config.isTouch || theme.config.mqlSmall ? 95 : 20) - headerHeight,
            behavior: theme.config.motionReduced ? 'auto' : 'smooth'
          });

          const drawer = document.getElementById('FacetDrawer');
          if (drawer) drawer.classList.add('loading');
        }, 100);
      }

      afterRenderSection() {
        const container = document.getElementById('ProductGridContainer');
        const items = container.querySelectorAll('.product-card');

        const { distance, duration, staggerDelay } = this.getAnimationParams();
        const { visible: visibleItems, invisible: inVisibleItems } = this.getVisibleItems(items);

        Motion.timeline([
          [container, { y: [distance, 0], opacity: [0, 1] }, { duration: duration, easing: 'linear' }],
          [visibleItems, { y: [distance, 0], opacity: [0, 1], visibility: ['hidden', 'visible'] }, { duration: duration, delay: Motion.stagger(staggerDelay) }],
          [inVisibleItems, { y: [distance, 0], opacity: [0, 1], visibility: ['hidden', 'visible'] }, { duration: duration }]
        ]);
        items.forEach(item => item.style.removeProperty('transform'));

        const drawer = document.getElementById('FacetDrawer');
        if (drawer) drawer.classList.remove('loading');

        document.dispatchEvent(new CustomEvent('collection:reloaded'));
      }

      renderSection(url, event) {
        this.renderAbortController?.abort();
        this.renderAbortController = new AbortController();
        const { signal } = this.renderAbortController;

        this.cachedMap.has(url)
          ? this.renderSectionFromCache(url, event, signal)
          : this.renderSectionFromFetch(url, event, signal);

        if (this.hasAttribute('data-history')) this.updateURLHash(url);

        this.dirty = false;
      }

      renderSectionFromFetch(url, event, signal) {
        this.beforeRenderSection();

        const delay = this.getAnimationParams().duration * 1000;
        const start = performance.now();

        fetch(url, { signal })
          .then((response) => response.text())
          .then((responseText) => {
            const remaining = Math.max(0, delay - (performance.now() - start));

            setTimeout(() => {
              if (signal.aborted) return;

              const parsedHTML = new DOMParser().parseFromString(responseText, 'text/html');
              this.applyRender(parsedHTML, event);

              theme.pubsub.publish(theme.pubsub.PUB_SUB_EVENTS.facetUpdate, { responseText, parsedHTML });

              this.cachedMap.set(url, responseText);
              if (this.cachedMap.size > 50) {
                this.cachedMap.delete(this.cachedMap.keys().next().value);
              }

              this.afterRenderSection();
            }, remaining);
          })
          .catch((error) => {
            if (error.name !== 'AbortError') console.error(error);
          });
      }

      renderSectionFromCache(url, event, signal) {
        this.beforeRenderSection();

        const responseText = this.cachedMap.get(url);
        const delay = this.getAnimationParams().duration * 1000;

        setTimeout(() => {
          if (signal.aborted) return;

          const parsedHTML = new DOMParser().parseFromString(responseText, 'text/html');
          this.applyRender(parsedHTML, event);

          theme.pubsub.publish(theme.pubsub.PUB_SUB_EVENTS.facetUpdate, { responseText, parsedHTML });

          this.afterRenderSection();
        }, delay);
      }

      applyRender(parsedHTML, event) {
        this.renderFilters(parsedHTML, event);
        this.renderFiltersActive(parsedHTML);
        this.renderProductGridContainer(parsedHTML);
        this.renderProductCount(parsedHTML);
        this.renderSortBy(parsedHTML);
      }

      renderFilters(parsedHTML, event) {
        const facetElements = parsedHTML.querySelectorAll(
          '#FacetFiltersContainer [data-filter], #MobileFacetFiltersContainer [data-filter]'
        );

        const matchesIndex = (element) => {
          const jsFilter = event ? event.target.closest('[data-filter]') : undefined;
          return jsFilter ? element.getAttribute('data-index') === jsFilter.getAttribute('data-index') : false;
        };
        const facetsToRender = Array.from(facetElements).filter((element) => !matchesIndex(element));

        facetsToRender.forEach((element) => {
          const filter = document.querySelector(`[data-filter][data-index="${element.getAttribute('data-index')}"]`);
          if (filter !== null) {
            if (filter.tagName === 'DETAILS') {
              filter.querySelector('summary + *').innerHTML = element.querySelector('summary + *').innerHTML;
            }
            else {
              filter.innerHTML = element.innerHTML;
            }
          }
        });
      }

      renderFiltersActive(parsedHTML) {
        this._updateSection(parsedHTML, 'FacetFiltersActive');
      }

      renderProductGridContainer(parsedHTML) {
        this._updateSection(parsedHTML, 'ProductGridContainer', (newContent) => {
          newContent.querySelector('motion-list')?.setAttribute('motion-reduced', '');
        });
      }

      renderProductCount(parsedHTML) {
        this._updateSection(parsedHTML, 'ProductCount');
      }

      renderSortBy(parsedHTML) {
        this._updateSection(parsedHTML, 'SortByContainer', (newContent, oldContainer) => {
          const oldFacetSort = oldContainer.querySelector('facet-sort');
          const newFacetSort = newContent.querySelector('facet-sort');
          if (!oldFacetSort || !newFacetSort) return;
          
          if (oldFacetSort.hasAttribute('style')) {
            newFacetSort.setAttribute('style', oldFacetSort.getAttribute('style'));
          }
        });
      }

      _updateSection(parsedHTML, sectionId, modifier = null) {
        const container = document.getElementById(sectionId);
        if (!container) return false;

        const newContent = parsedHTML.getElementById(sectionId);
        if (!newContent) return false;

        // Apply custom modifications if provided
        modifier?.(newContent, container);

        container.innerHTML = newContent.innerHTML;
        return true;
      }
    }, { extends: 'form' }
  );
}

if (!customElements.get('facet-count')) {
  customElements.define(
    'facet-count',
    class FacetCount extends BaseElement {

      connectedCallback() {
        super.connectedCallback();

        const facetUpdateUnsubscriber = theme.pubsub.subscribe(theme.pubsub.PUB_SUB_EVENTS.facetUpdate, this.onFacetUpdate.bind(this));
        this.registerCleanup(facetUpdateUnsubscriber);
      }

      get itemCount() {
        return parseInt(this.innerText);
      }

      onFacetUpdate(event) {
        const parsedHTML = event.parsedHTML || new DOMParser().parseFromString(event.responseText, 'text/html');
        const facetCount = parsedHTML.querySelector('facet-count');
        this.innerText = facetCount.innerHTML;
        this.hidden = this.itemCount === 0;
      }
    }
  );
}

if (!customElements.get('results-count')) {
  customElements.define(
    'results-count',
    class ResultsCount extends BaseElement {

      connectedCallback() {
        super.connectedCallback();

        const facetUpdateUnsubscriber = theme.pubsub.subscribe(theme.pubsub.PUB_SUB_EVENTS.facetUpdate, this.onFacetUpdate.bind(this));
        this.registerCleanup(facetUpdateUnsubscriber);
      }

      onFacetUpdate(event) {
        const parsedHTML = event.parsedHTML || new DOMParser().parseFromString(event.responseText, 'text/html');
        const resultsCount = parsedHTML.querySelector('results-count');
        this.innerText = resultsCount.innerHTML;
      }
    }
  );
}

if (!customElements.get('facet-remove')) {
  customElements.define(
    'facet-remove',
    class FacetRemove extends MagnetLink {
      connectedCallback() {
        super.connectedCallback();

        this.on(this, 'click', this.onClick);
      }

      onClick(event) {
        const form = this.closest('form[is="facet-form"]') || document.querySelector('form[is="facet-form"]');

        if (form) {
          event.preventDefault();

          const url = new URL(this.href);
          url.searchParams.set('section_id', theme.utils.sectionId(form));
          form.renderSection(url.toString(), event);
        }
      }
    }, { extends: 'a' }
  );
}

if (!customElements.get('facet-sort')) {
  customElements.define(
    'facet-sort',
    class FacetSort extends BaseElement {
      constructor() {
        super();

        Motion.inView(this, this.init.bind(this), { margin: '200px 0px 200px 0px' });
      }

      connectedCallback() {
        super.connectedCallback();

        this.on(this, 'change', this.onChange);
        this.on(this.button, 'click', this.show.bind(this));
        this.on(this.close, 'click', this.hide.bind(this));
        this.on(document, 'click', this.onWindowClick.bind(this));
      }

      get listbox() {
        return this.querySelector('.sort-listbox');
      }

      get selection() {
        return this.querySelector('.sort-selection');
      }

      get button() {
        return this.querySelector('.sort-by');
      }

      get close() {
        return this.querySelector('.sort-close');
      }

      init() {
        this.initButton();
        this.style.setProperty('--facet-listbox-height', `${this.listbox.getBoundingClientRect().height.toFixed(1)}px`);
      }

      initButton() {
        const value = this.selection.innerText;
        const width = theme.getElementWidth(this.selection, value);
        this.style.setProperty('--facet-button-width', `${width}px`);
      }

      onChange(event) {
        const form = this.closest('form[is="facet-form"]') || document.querySelector('form[is="facet-form"]');

        if (form) {
          const url = new URL(window.location.href);
          url.searchParams.set('sort_by', event.target.value);
          url.searchParams.set('section_id', theme.utils.sectionId(form));
          url.searchParams.delete('page');
          form.renderSection(url.toString(), event);
        }

        this.selection.innerText = event.target.nextElementSibling.innerText;
        this.initButton();
        this.hide();
      }

      show() {
        this.button.setAttribute('open', '');
      }

      hide(immediate = true) {
        if (this.button.hasAttribute('open')) {
          setTimeout(() => {
            this.button.removeAttribute('open');
          }, 100);

          if (theme.config.isTouch || document.body.getAttribute('data-button-hover') === 'none') return;
          
          const btnFill = this.button.querySelector('[data-fill]');
          Motion.animate(btnFill, { y: ['0%', immediate ? '0%' : '-76%'] }, { duration: 0.6, delay: immediate ? 0 : 0.2 });
        }
      }

      onWindowClick(event) {
        if (!this.contains(event.target)) {
          if (this.button.hasAttribute('open')) {
            this.hide(false);
          }
        }
      }
    }
  );
}

if (!customElements.get('facet-sticky')) {
  customElements.define(
    'facet-sticky',
    class FacetSticky extends BaseElement {
      constructor() {
        super();

        const collectionSection = document.querySelector('.collection-section');
        if (collectionSection) {
          const observer = new IntersectionObserver(this.handleIntersection.bind(this), { rootMargin: `-${screen.availHeight - 200}px 0px ${screen.availHeight}px 0px` });
          observer.observe(collectionSection);
          this.registerCleanup(() => observer.disconnect());
        }
      }

      get button() {
        return this.querySelector('.button');
      }

      handleIntersection(entries) {
        if (entries[0].isIntersecting) {
          Motion.animate(this.button, { opacity: 1, visibility: 'visible', transform: ['translateY(15px)', 'translateY(0)'] }, { duration: 1, easing: [0.16, 1, 0.3, 1] });
        }
        else {
          Motion.animate(this.button, { opacity: 0, visibility: 'hidden', transform: ['translateY(0)', 'translateY(15px)'] }, { duration: 1, easing: [0.16, 1, 0.3, 1] });
        }
      }
    }
  );
}

if (!customElements.get('price-range')) {
  customElements.define(
    'price-range',
    class PriceRange extends BaseElement {
      connectedCallback() {
        super.connectedCallback();

        this.rangeMin = this.querySelector('input[type="range"]:first-child');
        this.rangeMax = this.querySelector('input[type="range"]:last-child');
        this.inputMin = this.querySelector('input[name="filter.v.price.gte"]');
        this.inputMax = this.querySelector('input[name="filter.v.price.lte"]');

        this.on(this.inputMin, 'focus', this.inputMin.select);
        this.on(this.inputMax, 'focus', this.inputMax.select);
        this.on(this.inputMin, 'change', this.onInputMinChange.bind(this));
        this.on(this.inputMax, 'change', this.onInputMaxChange.bind(this));

        this.on(this.rangeMin, 'change', this.onRangeMinChange.bind(this));
        this.on(this.rangeMax, 'change', this.onRangeMaxChange.bind(this));
        this.on(this.rangeMin, 'input', this.onRangeMinInput.bind(this));
        this.on(this.rangeMax, 'input', this.onRangeMaxInput.bind(this));
      }

      onInputMinChange(event) {
        event.preventDefault();
        const target = event.target;
        target.value = Math.max(Math.min(parseInt(target.value || target.min), parseInt(this.inputMax.value || target.max) - 1), target.min);
        this.rangeMin.value = target.value;
        this.rangeMin.parentElement.style.setProperty('--range-min', `${parseInt(this.rangeMin.value) / parseInt(this.rangeMin.max) * 100}%`);
      }

      onInputMaxChange(event) {
        event.preventDefault();
        const target = event.target;
        target.value = Math.min(Math.max(parseInt(target.value || target.max), parseInt(this.inputMin.value || target.min) + 1), target.max);
        this.rangeMax.value = target.value;
        this.rangeMax.parentElement.style.setProperty('--range-max', `${parseInt(this.rangeMax.value) / parseInt(this.rangeMax.max) * 100}%`);
      }

      onRangeMinChange(event) {
        event.stopPropagation();
        this.inputMin.value = event.target.value;
        this.inputMin.dispatchEvent(new Event('change', { bubbles: true }));
      }

      onRangeMaxChange(event) {
        event.stopPropagation();
        this.inputMax.value = event.target.value;
        this.inputMax.dispatchEvent(new Event('change', { bubbles: true }));
      }

      onRangeMinInput(event) {
        event.target.value = Math.min(parseInt(event.target.value), parseInt(this.inputMax.value || event.target.max) - 1);
        event.target.parentElement.style.setProperty('--range-min', `${parseInt(event.target.value) / parseInt(event.target.max) * 100}%`);
        this.inputMin.value = event.target.value;
      }

      onRangeMaxInput(event) {
        event.target.value = Math.max(parseInt(event.target.value), parseInt(this.inputMin.value || event.target.min) + 1);
        event.target.parentElement.style.setProperty('--range-max', `${parseInt(event.target.value) / parseInt(event.target.max) * 100}%`);
        this.inputMax.value = event.target.value;
      }
    }
  );
}

if (!customElements.get('infinite-button')) {
  customElements.define(
    'infinite-button',
    class InfiniteButton extends HoverButton {
      constructor() {
        super();

        this.onClickHandler = this.onClick.bind(this);
      }

      connectedCallback() {
        super.connectedCallback();

        this.on(this, 'click', this.onClickHandler);

        if (this.getAttribute('mode') == 'infinite') {
          Motion.inView(this, this.onClickHandler, { margin: '200px 0px 200px 0px' });
        }
      }

      disconnectedCallback() {
        super.disconnectedCallback();

        this.loadMoreAbortController?.abort();
      }

      onClick() {
        if (this.hasAttribute('aria-busy')) return;

        this.loadMoreAbortController?.abort();
        this.loadMoreAbortController = new AbortController();

        this.enableLoading();
        const url = this.buildUrl().toString();

        fetch(url, { signal: this.loadMoreAbortController.signal })
          .then((response) => response.text())
          .then((responseText) => {
            const parsedHTML = new DOMParser().parseFromString(responseText, 'text/html');
            this.renderPagination(parsedHTML);
            this.renderProductGridContainer(parsedHTML);
          })
          .catch((error) => {
            if (error.name !== 'AbortError') console.error(error);
          });
      }

      renderPagination(parsedHTML) {
        const productGridContainer = document.getElementById('ProductGridContainer');
        if (productGridContainer === null) return;

        const destination = productGridContainer.querySelector('.pagination');
        const source = parsedHTML.querySelector('.pagination');

        if (source) {
          destination.innerHTML = source.innerHTML;
        }
        else {
          destination.remove();
        }
      }

      renderProductGridContainer(parsedHTML) {
        const productGridContainer = document.getElementById('ProductGridContainer');
        if (productGridContainer === null) return;

        const destination = productGridContainer.querySelector('motion-list');
        const source = parsedHTML.querySelector('motion-list');

        if (source && destination) {
          source.querySelectorAll('.card').forEach((item) => {
            destination.appendChild(item);
          });

          destination.reload();
        }
      }
      
      buildUrl() {
        const url = new URL(this.getAttribute('action'));
        url.searchParams.set('section_id', theme.utils.sectionId(this));
        return url;
      }

      enableLoading() {
        this.classList.add('pointer-events-none');
        this.setAttribute('aria-busy', 'true');
      }
    }, { extends: 'button' }
  );
}

if (!customElements.get('facets-topbar')) {
  customElements.define(
    'facets-topbar',
    class FacetsTopbar extends StickyElement {

      positionStickySidebar() {
        const bounding = this.getBoundingClientRect();
        if (bounding.top === 0) {
          document.body.classList.add('facets-topbar--active');
        }
        else {
          document.body.classList.remove('facets-topbar--active');
        }
      }
    }
  );
}

if (!customElements.get('model-view')) {
  customElements.define(
    'model-view',
    class ModelView extends MagnetButton {
      constructor() {
        super();

        Motion.inView(this, this.init.bind(this), { margin: '200px 0px 200px 0px' });

        this._open = this.hasAttribute('open');
        this.onClickHandler = this.onClick.bind(this);
        this.textSpans = this.querySelectorAll('.link-text');
      }

      set open(value) {
        if (value !== this._open) {
          this._open = value;
          value ? this.setAttribute('open', '') : this.removeAttribute('open');
        }
      }

      static get observedAttributes() {
        return ['open'];
      }

      get open() {
        return this._open;
      }

      connectedCallback() {
        super.connectedCallback();

        this.on(this, 'click', this.onClickHandler);
      }

      attributeChangedCallback(name, oldValue, newValue) {
        if (name === 'open') {
          const isActive = newValue === '';
          this.setActiveModel(isActive);
          this.updateAccessibility(isActive);
        }
      }

      init() {
        if (theme.config.hasLocalStorage) {
          const isActive = window.localStorage.getItem(`${theme.settings.themeName}:model-view`) || 'false';
          this.open = isActive === 'true';
        }
      }

      onClick(event) {
        event.preventDefault();
        this.open = !this.open;
      }

      setActiveModel(isActive) {
        const container = document.getElementById('ProductGridContainer');
        container.classList.toggle('lifestyle', isActive);

        container.querySelectorAll('video-media').forEach((videoMedia) => videoMedia.pause());

        if (theme.config.hasLocalStorage) {
          window.localStorage.setItem(`${theme.settings.themeName}:model-view`, isActive);
        }
      }

      updateAccessibility(isActive) {
        if (this.textSpans.length === 2) {
          const [defaultText, activeText] = this.textSpans;
          this.setAttribute('aria-label', isActive ? activeText.textContent.trim() : defaultText.textContent.trim());
        }
      }
    }, { extends: 'button' }
  );
}

if (!customElements.get('sub-collections')) {
  customElements.define(
    'sub-collections',
    class SubCollections extends BaseElementMixin(HTMLSelectElement) {
      connectedCallback() {
        super.connectedCallback();

        this.on(this, 'change', this.onChange);
      }
    
      onChange() {
        window.location.href = this.value;
      }
    }, { extends: 'select' }
  );
}
